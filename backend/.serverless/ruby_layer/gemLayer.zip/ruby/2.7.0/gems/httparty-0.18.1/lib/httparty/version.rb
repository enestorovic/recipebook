module HTTParty
  VERSION = "0.18.1"
end
