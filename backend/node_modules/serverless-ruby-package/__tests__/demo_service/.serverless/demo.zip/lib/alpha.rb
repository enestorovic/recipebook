module Alpha
  def self.describe
    "first"
  end
end
