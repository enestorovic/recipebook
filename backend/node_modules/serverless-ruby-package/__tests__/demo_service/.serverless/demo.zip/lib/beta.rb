module Beta
  def self.describe
    "second"
  end
end
